#ifndef COEUR_H
#define COEUR_H
#include "param.h"
#include <stdio.h>
#include <stdlib.h>


void on();
void off();
void halfOn();
void thirdOn();
void progressive();
void choiceLed(int choice);

#endif
