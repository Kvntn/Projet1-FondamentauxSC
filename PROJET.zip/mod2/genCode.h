int		gencode(int param, int choice);
