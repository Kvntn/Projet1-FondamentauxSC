#ifndef CARDIO_H
#define CARDIO_H
#include <Arduino.h>

void pouls();

#endif
