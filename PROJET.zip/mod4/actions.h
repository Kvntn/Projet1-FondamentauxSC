int		display_data(int n);
int		tri_croissant(int choice, int n);
int		tri_decroissant(int choice, int n);
int		search_time(int time, int n);
int		moyenne(int min, int max, int n);
int		nb_ligne();
int		search_min(int n);
int		search_max(int n);
