#ifndef ACTIONS_H
#define ACTIONS_H

typedef struct DATA
{
	int temps;
	int pouls;
	}DATA;

FILE*	open_beat_file();
#endif
